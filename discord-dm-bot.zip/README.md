# Discord DM Bot

A feature-rich Discord bot built with **discord.py** supporting both prefix (`!`) and slash (`/`) commands.

## Features

| Command | Prefix | Slash | Description |
|---|---|---|---|
| dm | `!dm @user <message>` | `/dm` | Send a DM to a specific user |
| broadcast | `!broadcast <message>` | `/broadcast` | DM all server members *(Admin only)* |
| announce | `!announce #channel <title> \| <message>` | `/announce` | Post an embed to a channel *(Admin only)* |
| help | `!help` | `/help` | Show all commands |

## Requirements

- Python 3.10+
- A Discord bot token ([Discord Developer Portal](https://discord.com/developers/applications))

## Setup

### 1. Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
cd YOUR_REPO_NAME
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Set your bot token

**Linux / macOS:**
```bash
export TOKEN=your_bot_token_here
```

**Windows (Command Prompt):**
```cmd
set TOKEN=your_bot_token_here
```

**Windows (PowerShell):**
```powershell
$env:TOKEN="your_bot_token_here"
```

> Never hardcode your token. Never commit it to Git.

### 4. Run the bot

```bash
python main.py
```

## Discord Developer Portal Settings

Before the bot works correctly, make sure these are enabled in the [Developer Portal](https://discord.com/developers/applications) under your bot's **Bot** tab:

- **Message Content Intent** — required for prefix commands (`!dm`, `!broadcast`, etc.)
- **Server Members Intent** — required for `!broadcast` to see all server members

## Deploying for 24/7 Hosting

### Option A — VPS (e.g. DigitalOcean, Linode, Hetzner)

1. SSH into your VPS and clone the repo:
   ```bash
   git clone https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
   cd YOUR_REPO_NAME
   pip install -r requirements.txt
   ```

2. Set your token as an environment variable (add to `~/.bashrc` or `~/.profile` for persistence):
   ```bash
   export TOKEN=your_bot_token_here
   ```

3. Run with `screen` or `tmux` so it keeps running after you disconnect:
   ```bash
   screen -S discordbot
   python main.py
   # Press Ctrl+A then D to detach
   ```

   Or use `systemd` for a proper service (recommended for production):
   ```ini
   # /etc/systemd/system/discordbot.service
   [Unit]
   Description=Discord Bot
   After=network.target

   [Service]
   User=your_user
   WorkingDirectory=/path/to/repo
   ExecStart=/usr/bin/python3 main.py
   Environment=TOKEN=your_bot_token_here
   Restart=always

   [Install]
   WantedBy=multi-user.target
   ```
   ```bash
   sudo systemctl enable discordbot
   sudo systemctl start discordbot
   ```

### Option B — ModVC

1. Go to [ModVC](https://modvc.net) and create an account.
2. Create a new **Python** project.
3. Connect your GitHub repository:
   - In your ModVC dashboard, select **Connect GitHub**
   - Authorize ModVC to access your repo
   - Choose this repository from the list
4. Set the environment variable:
   - In ModVC dashboard → **Environment Variables**
   - Add key: `TOKEN`, value: your bot token
5. Set the start command to:
   ```
   python main.py
   ```
6. Click **Deploy** — ModVC will pull from GitHub, install `requirements.txt` automatically, and keep the bot running 24/7.

> Whenever you push changes to GitHub, redeploy in ModVC to pick them up.

## Project Structure

```
.
├── main.py          # Bot source code
├── requirements.txt # Python dependencies
├── .gitignore       # Excludes secrets and cache files
└── README.md        # This file
```

## Security Notes

- Your `TOKEN` is read from an environment variable — it is **never** in the source code
- `.gitignore` excludes `.env` files to prevent accidental commits
- Do not share your token publicly — regenerate it in the Developer Portal if it leaks
